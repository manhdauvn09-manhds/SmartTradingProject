import logging
from models.stock_data import StockData

logger = logging.getLogger(__name__)

class StockRepository:
    def __init__(self):
        """
        Khởi tạo Repository. 
        Phiên bản này không cần kết nối database nên không cần 'session'.
        """
        logger.info("StockRepository (phiên bản giả lập) đã được khởi tạo.")

    def save(self, stock_data: StockData):
        """
        Lưu trữ dữ liệu cổ phiếu. 
        Trong phiên bản này, nó chỉ in ra log để mô phỏng.
        """
        # Trong một ứng dụng thực tế, đây là nơi bạn sẽ viết code để
        # lưu stock_data vào PostgreSQL, MySQL, hoặc một DB khác.
        
        logger.info(
            f"Đang LUU (giả lập) dữ liệu vào DB cho mã: {stock_data.symbol} "
            f"với giá đóng cửa {stock_data.closing_price} "
            f"tại thời điểm {stock_data.timestamp}"
        )
